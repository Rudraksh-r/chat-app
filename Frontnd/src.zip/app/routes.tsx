import { createBrowserRouter } from "react-router";
import { Login } from "./pages/Login";
import { Signup } from "./pages/Signup";
import { ChatLayout } from "./pages/ChatLayout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: ChatLayout,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/signup",
    Component: Signup,
  }
]);