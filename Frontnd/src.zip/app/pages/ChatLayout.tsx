import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, Plus, Bell, Settings, MoreVertical, 
  Phone, Video, Paperclip, Smile, Send, Check, CheckCheck, Menu, X
} from "lucide-react";
import { formatTime, cn } from "../lib/utils";
import { Button, Input, Avatar } from "../components/ui/index";
import { currentUser, mockChats, mockMessages, mockUsers } from "../data/mock";

export function ChatLayout() {
  const [activeChatId, setActiveChatId] = useState<string | null>("c1");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeChatId, mockMessages]);

  const activeChat = mockChats.find(c => c.id === activeChatId);
  const activeChatMessages = activeChatId ? mockMessages[activeChatId] || [] : [];
  
  // Resolve other participant details for 1-on-1 chats
  const otherParticipantId = activeChat && !activeChat.isGroup 
    ? activeChat.participants.find(id => id !== currentUser.id)
    : null;
  const otherParticipant = otherParticipantId ? mockUsers.find(u => u.id === otherParticipantId) : null;

  const chatTitle = activeChat?.isGroup ? activeChat.name : otherParticipant?.name;
  const chatAvatar = activeChat?.isGroup ? activeChat.avatar : otherParticipant?.avatar;
  const chatStatus = activeChat?.isGroup ? "online" : otherParticipant?.status;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    // In a real app, this would append to the state or call an API.
    setMessageText("");
  };

  return (
    <div className="flex h-screen w-full bg-[#0F172A] text-slate-200 overflow-hidden font-sans">
      
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {!sidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setSidebarOpen(true)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.div 
        className={cn(
          "fixed md:relative z-50 flex flex-col w-80 h-full bg-[#111827] border-r border-slate-800/60 shrink-0 transition-transform duration-300 ease-in-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        {/* Sidebar Header */}
        <div className="p-4 flex items-center justify-between border-b border-slate-800/60">
          <div className="flex items-center gap-3">
            <Avatar src={currentUser.avatar} status="online" />
            <div>
              <h2 className="font-semibold text-slate-100 text-sm">{currentUser.name}</h2>
              <p className="text-xs text-indigo-400">My Profile</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400">
              <Settings className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 md:hidden" onClick={() => setSidebarOpen(false)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Search & Actions */}
        <div className="p-4 space-y-4 border-b border-slate-800/60">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search chats..." 
              className="w-full bg-[#0F172A] text-sm text-slate-200 rounded-lg pl-9 pr-4 py-2 border border-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all placeholder:text-slate-500"
            />
          </div>
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Messages</h3>
            <Button variant="ghost" size="icon" className="h-6 w-6 text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/10">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden custom-scrollbar">
          {mockChats.map((chat) => {
            const isGroup = chat.isGroup;
            const otherUser = !isGroup ? mockUsers.find(u => u.id === chat.participants.find(id => id !== currentUser.id)) : null;
            const name = isGroup ? chat.name : otherUser?.name;
            const avatar = isGroup ? chat.avatar : otherUser?.avatar;
            const status = isGroup ? null : otherUser?.status;
            const isActive = activeChatId === chat.id;

            return (
              <div 
                key={chat.id}
                onClick={() => { setActiveChatId(chat.id); setSidebarOpen(false); }}
                className={cn(
                  "flex items-center gap-3 p-3 mx-2 my-1 rounded-xl cursor-pointer transition-all group",
                  isActive ? "bg-indigo-600/10" : "hover:bg-slate-800/50"
                )}
              >
                <Avatar src={avatar} status={status as any} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <h4 className={cn("text-sm font-medium truncate", isActive ? "text-indigo-400" : "text-slate-200")}>{name}</h4>
                    <span className="text-xs text-slate-500 whitespace-nowrap ml-2">
                      {formatTime(chat.lastMessage.timestamp)}
                    </span>
                  </div>
                  <p className={cn(
                    "text-xs truncate", 
                    chat.unread > 0 ? "text-slate-300 font-medium" : "text-slate-500"
                  )}>
                    {chat.lastMessage.text}
                  </p>
                </div>
                {chat.unread > 0 && (
                  <div className="w-5 h-5 rounded-full bg-indigo-500 flex items-center justify-center shrink-0 shadow-sm shadow-indigo-500/20">
                    <span className="text-[10px] font-bold text-white">{chat.unread}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#0F172A] relative">
        {activeChatId ? (
          <>
            {/* Chat Header */}
            <div className="h-16 border-b border-slate-800/60 bg-[#111827]/80 backdrop-blur-md flex items-center justify-between px-4 sm:px-6 shrink-0 sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <Button variant="ghost" size="icon" className="md:hidden mr-1 -ml-2 text-slate-400" onClick={() => setSidebarOpen(true)}>
                  <Menu className="w-5 h-5" />
                </Button>
                <Avatar src={chatAvatar} status={chatStatus as any} />
                <div>
                  <h2 className="font-semibold text-slate-100 text-sm sm:text-base">{chatTitle}</h2>
                  <p className="text-xs text-slate-400 flex items-center gap-1">
                    {chatStatus === "online" ? (
                      <><span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" /> Online</>
                    ) : (
                      "Last seen recently"
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 sm:gap-2">
                <Button variant="ghost" size="icon" className="text-slate-400 hover:text-indigo-400 hidden sm:flex">
                  <Phone className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-slate-400 hover:text-indigo-400 hidden sm:flex">
                  <Video className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-slate-400">
                  <Search className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-slate-400">
                  <MoreVertical className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar bg-gradient-to-b from-transparent to-slate-900/20">
              {activeChatMessages.map((msg, index) => {
                const isMe = msg.senderId === currentUser.id;
                const sender = isMe ? currentUser : mockUsers.find(u => u.id === msg.senderId);
                const showAvatar = index === 0 || activeChatMessages[index - 1].senderId !== msg.senderId;

                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={msg.id} 
                    className={cn("flex w-full", isMe ? "justify-end" : "justify-start")}
                  >
                    <div className={cn("flex max-w-[85%] sm:max-w-[70%] gap-2 sm:gap-3", isMe ? "flex-row-reverse" : "flex-row")}>
                      {showAvatar ? (
                        <div className="shrink-0 mt-auto">
                           <Avatar src={sender?.avatar} size="sm" />
                        </div>
                      ) : (
                        <div className="w-8 shrink-0" /> // Spacer for alignment
                      )}
                      
                      <div className={cn(
                        "flex flex-col", 
                        isMe ? "items-end" : "items-start"
                      )}>
                        <div className={cn(
                          "px-4 py-2.5 rounded-2xl shadow-sm",
                          isMe 
                            ? "bg-indigo-600 text-white rounded-br-sm shadow-indigo-600/10" 
                            : "bg-[#1E293B] text-slate-200 rounded-bl-sm border border-slate-800/50"
                        )}>
                          <p className="text-[15px] leading-relaxed break-words">{msg.text}</p>
                        </div>
                        <div className="flex items-center gap-1 mt-1 px-1">
                          <span className="text-[11px] text-slate-500">{formatTime(msg.timestamp)}</span>
                          {isMe && (
                            <span className="text-indigo-400">
                              {msg.status === "read" ? <CheckCheck className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
              
              {/* Fake typing indicator */}
              {activeChatId === "c1" && (
                <div className="flex w-full justify-start mt-4">
                  <div className="flex max-w-[70%] gap-3">
                    <div className="shrink-0 mt-auto">
                       <Avatar src={chatAvatar} size="sm" />
                    </div>
                    <div className="px-4 py-3.5 rounded-2xl bg-[#1E293B] text-slate-200 rounded-bl-sm border border-slate-800/50 flex items-center gap-1.5 h-11">
                      <motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0 }} className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                      <motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                      <motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} className="h-1" />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-[#111827] border-t border-slate-800/60 shrink-0">
              <form onSubmit={handleSendMessage} className="flex items-end gap-2 max-w-4xl mx-auto">
                <Button type="button" variant="ghost" size="icon" className="text-slate-400 hover:text-slate-300 hover:bg-slate-800 mb-1 shrink-0">
                  <Paperclip className="w-5 h-5" />
                </Button>
                
                <div className="flex-1 bg-[#0F172A] border border-slate-800/80 rounded-2xl flex items-end focus-within:ring-1 focus-within:ring-indigo-500 focus-within:border-indigo-500 transition-all shadow-inner shadow-black/10">
                  <Button type="button" variant="ghost" size="icon" className="text-slate-400 hover:text-yellow-500 mb-1 ml-1 shrink-0">
                    <Smile className="w-5 h-5" />
                  </Button>
                  <textarea 
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder="Type a message..."
                    className="w-full bg-transparent text-slate-200 py-3 px-2 max-h-32 min-h-[44px] outline-none resize-none text-[15px] placeholder:text-slate-500 custom-scrollbar"
                    rows={1}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage(e);
                      }
                    }}
                  />
                </div>

                <Button 
                  type="submit" 
                  size="icon" 
                  disabled={!messageText.trim()}
                  className={cn(
                    "mb-1 shrink-0 rounded-xl transition-all duration-200 h-11 w-11",
                    messageText.trim() 
                      ? "bg-indigo-600 text-white hover:bg-indigo-700 shadow-md shadow-indigo-600/20" 
                      : "bg-slate-800 text-slate-500"
                  )}
                >
                  <Send className="w-5 h-5 ml-1" />
                </Button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-500 p-8 text-center bg-gradient-to-b from-[#0F172A] to-[#111827]">
             <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mb-6 shadow-xl shadow-black/20 border border-slate-700/50">
               <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-slate-400">
                  <path d="M21 11.5C21.0034 12.8199 20.6951 14.1219 20.1 15.3C19.3944 16.7118 18.3098 17.8992 16.9674 18.7293C15.6251 19.5594 14.0782 19.9994 12.5 20C11.1801 20.0035 9.87812 19.6951 8.7 19.1L3 21L4.9 15.3C4.30493 14.1219 3.99656 12.8199 4 11.5C4.00061 9.92179 4.44061 8.37488 5.27072 7.03258C6.10083 5.69028 7.28825 4.6056 8.7 3.90003C9.87812 3.30496 11.1801 2.99659 12.5 3C14.7533 3.00305 16.913 3.89966 18.5055 5.49216C20.098 7.08466 20.9946 9.24436 20.997 11.5H21Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
               </svg>
             </div>
             <h3 className="text-xl font-semibold text-slate-200 mb-2">Figma Chat App</h3>
             <p className="max-w-md">Select a conversation from the sidebar or start a new one to begin messaging.</p>
             <Button className="mt-8">Start a new chat</Button>
          </div>
        )}
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #334155;
          border-radius: 10px;
        }
        .custom-scrollbar:hover::-webkit-scrollbar-thumb {
          background-color: #475569;
        }
      `}</style>
    </div>
  );
}